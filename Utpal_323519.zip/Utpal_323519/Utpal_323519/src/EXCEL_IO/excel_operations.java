package EXCEL_IO;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class excel_operations {
	Logger log;
	public void read_excel(ArrayList<Person> arr) {
		log = Logger.getLogger("devpinoyLogger");
		log.info("Excel read method is invoked.");
		try {
			ArrayList<String> storage_string = new ArrayList<String>(12);
			File f = new File("D:\\Excel\\check5.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			Iterator<Row> array_row = sh.iterator();
			Row row = array_row.next();
			while(array_row.hasNext()) {
				row = array_row.next();
				Iterator<Cell> array_cell = row.cellIterator();
				Person obj = new Person();
				while(array_cell.hasNext()) {
					Cell cell = array_cell.next();
					if(cell.getCellType() == 0) {
						storage_string.add(Long.toString((long)cell.getNumericCellValue()));
					}
					else {
						storage_string.add(cell.getStringCellValue());
					}
				}
				obj.put_data(storage_string);
				for(int i=11;i>=0;i--) {
					storage_string.remove(i);
				}
				arr.add(obj);
				wb.close();
			}
		}catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
}
