package EXCEL_IO;

import java.util.ArrayList;

import org.apache.log4j.Logger;

public class Person {
	Logger log;
	public String first_name;
	public String last_name;
	public String email;
	public String password;
	public String address;
	public String city;
	public String state;
	public String zip;
	public String country;
	public String mobile_phone;
	public String future_address;
	public String expected;
	public String actual;
	void put_data(ArrayList<String> storage_string) {
		log = Logger.getLogger("devpinoyLogger");
		log.info("Put data method is invoked");
		this.first_name = storage_string.get(0);
		this.last_name = storage_string.get(1);
		this.email = storage_string.get(2);
		this.password = storage_string.get(3);
		this.address = storage_string.get(4);
		this.city = storage_string.get(5);
		this.state = storage_string.get(6);
		this.zip = storage_string.get(7);
		this.country = storage_string.get(8);
		this.mobile_phone = storage_string.get(9);
		this.future_address = storage_string.get(10);
		this.expected = storage_string.get(11);
	}
}
