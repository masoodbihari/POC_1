package REUSABLE_AUT_CLASSES;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import EXCEL_IO.Person;;

public class aut_features {
	WebDriver dr;
	Logger log;
	public aut_features(){
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
	}
	public void open_browser() {
		this.log = Logger.getLogger("devpinoyLogger");
		log.info("Chrome browser launched");
		dr = new ChromeDriver();
		dr.get("http://automationpractice.com/index.php");
	}
	public void click_signin() {
		try {
			log.info("Signin button clicked");
			dr.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")).click();
		}
		catch(Exception e) {
			System.out.println("Unable to find webelement");
		}
	}
	public void create_account(ArrayList<Person> arr,int i){
		try {
			log.info("Create Account method invoked");
			dr.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			dr.findElement(By.xpath("//*[@id=\"email_create\"]")).sendKeys(arr.get(i).email);
			dr.findElement(By.xpath("//*[@id=\"SubmitCreate\"]")).click();
			dr.findElement(By.xpath("//*[@id=\"customer_firstname\"]")).sendKeys(arr.get(i).first_name);
			dr.findElement(By.xpath("//*[@id=\"customer_lastname\"]")).sendKeys(arr.get(i).last_name);
			dr.findElement(By.xpath("//*[@id=\"passwd\"]")).sendKeys(arr.get(i).password);
			dr.findElement(By.xpath("//*[@id=\"firstname\"]")).sendKeys(arr.get(i).first_name);
			dr.findElement(By.xpath("//*[@id=\"lastname\"]")).sendKeys(arr.get(i).last_name);
			dr.findElement(By.xpath("//*[@id=\"address1\"]")).sendKeys(arr.get(i).address);
			dr.findElement(By.xpath("//*[@id=\"city\"]")).sendKeys(arr.get(i).city);
			dr.findElement(By.xpath("//*[@id=\"id_state\"]")).sendKeys(arr.get(i).state);
			dr.findElement(By.xpath("//*[@id=\"postcode\"]")).sendKeys(arr.get(i).zip);
			dr.findElement(By.xpath("//*[@id=\"id_country\"]")).sendKeys(arr.get(i).country);
			dr.findElement(By.xpath("//*[@id=\"phone_mobile\"]")).sendKeys(arr.get(i).mobile_phone);
			dr.findElement(By.xpath("//*[@id=\"alias\"]")).sendKeys(arr.get(i).future_address);
			dr.findElement(By.xpath("//*[@id=\"submitAccount\"]")).click();
			//dr.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			String str = dr.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")).getText();
			arr.get(i).actual = str;
			dr.close();
		}catch(Exception e) {
			dr.close();
			System.out.println("Unable to find webelement.");
		}
	}
}
