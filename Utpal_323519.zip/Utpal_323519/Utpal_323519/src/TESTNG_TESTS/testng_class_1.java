package TESTNG_TESTS;

import EXCEL_IO.excel_operations;
import REUSABLE_AUT_CLASSES.aut_features;
import EXCEL_IO.Person;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class testng_class_1 {
	aut_features feature_obj;
	excel_operations obj_excel;
	ArrayList<Person> arr;
	SoftAssert sa;
	Logger log;
	int status;
	int test_number;
	@BeforeClass
	public void BC() {
		//System.out.println("data provider");
		arr = new ArrayList<Person>();
		this.log = Logger.getLogger("devpinoyLogger");
		log.info("Before class invoked");
		obj_excel = new excel_operations();
		obj_excel.read_excel(arr);
		feature_obj = new aut_features();
		sa = new SoftAssert();
		status = 0;
		test_number = 1;
	}
	@DataProvider(name="data")
	public String[] get_test_data() {
		//System.out.println(arr.size());
		log.info("Data provider method invoked");
		String expected[] = new String[arr.size()];
		for(int i=0;i<arr.size();i++)
			expected[i] = arr.get(i).expected;
		return expected;
	}
	@BeforeMethod
	public void BM() {
		log.info("Before method function invoked");
		feature_obj.open_browser();
		feature_obj.click_signin();
	}
	@Test(dataProvider="data")
	public void test_case(String expected) {
		//System.out.println("test method");
		log.info("Test Case : " + test_number);
		test_number++;
		feature_obj.create_account(arr, status);
		sa.assertEquals(arr.get(status).actual, expected);
		log.info("expected result :" + expected + "  actual result :" + arr.get(status).actual);
		status++;
		sa.assertAll();
	}
	@AfterClass
	public void AC() {
		log.info("After class invoked");
		//removing the array of object of class Person for memory efficiency
		for(int i=arr.size()-1;i>=0;i--) {
			arr.remove(i);
		}
	}

}
